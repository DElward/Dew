// JavaScript source code
// jstest02.js

//  function inchestometers(inches) {
//      if (inches < 0)
//          return -1;
//      else {
//          var meters = inches / 39.37;
//          return meters;
//      }
//  }
//  
//  function t1() {
//      console.log("function t1");
//      return true;
//  }
//  function t2() {
//      console.log("function t2");
//      return true;
//  }
//  function f1() {
//      console.log("function f1");
//      return false;
//  }
//  
//  console.log("eval (t1 || (t2 || f1))=" + (t1() || (t2() || f1())));
//  
//  var inches = 12;
//  var meters = inchestometers(inches);
//  console.log("the value in meters is " + meters);
//  
//  setTimeout(function () { process.exit(); }, 1000);
//  
//  **** Output:
//  ****    function t1
//  ****    eval (t1 || (t2 || f1))=true
//  ****    the value in meters is 0.30480060960121924

//  function foo() {
//      var x = 1;
//      function bar() {
//          var y = 2;
//          console.log(x); // 1 (function `bar` closes over `x`)
//          console.log(y); // 2 (`y` is in scope)
//      }
//      bar();
//      console.log(x); // 1 (`x` is in scope)
//      console.log(y); // ReferenceError in strict mode, `y` is scoped to `bar`
//  }
//  
//  foo();

//  var x = 1;
//  {
//      var x = 2;
//  }
//  console.log(x); // outputs 2

////////////////////////////////////////////////////////////////

// var \u0041\u0062\u0063 = "Def";

//{()[]....;@#,<><=>===!====!==+-*%**++--<<>>>>>&|^!~&&||???:=+=-=*=%=**=<<=>>=>>>=&=|=^==>}

//  var \u0077\u0061\u0072 = 2;
//  console.log("A value in meters is whatever: " + \u0077\u0061\u0072);

//var op1 = '2', op2 = '3';
//var tot;
//tot = op1 + op2;
//  ii=1 jj=0 kk=0
//  ii=1 jj=1 kk=0
////////////////////////////////////////////////////////////////
var msg = "the value in meters is";
@@
console.log("the value in meters is");
@@
false && (false || true);
@@
// Good
false && aa || true;
(false && aa);
(true || aa);
true || (aa);
true || false && false;
true || true && false;
true || (aa);
false || (false && aa);
true && false && aa;
false || false && aa;
true || aa;
@@
// Good
4 ** 3 * 2 - 112;
1 + 2 * 3 ** 4 - 147;
-(-(-(2)) ** -(-2 ** 2));
-(-(2)) * -(-(2)) * -(-(2)) * -(-(2));
((((4)+4)+4)+4);
(4+(4+(4+(4))));
2 * 5 + 3 * (3 - 1) ** (5 - 2) - 6 * 3;
2 * 5 + 3 * (3 - 1);
- -2 ** 4;
-2 * -8;
2 * (3 + 5);
(7 + 9);
2 + 7 * 2;
16;
7 + 9;
@@
////////////////////////////////////////////////////////////////
false || (false && aa);
@@
false || false && aa;
@@
true || false && aa;
false || false && aa;
false && aa || true;
true && true && false && aa;
false || false || true || aa;
false && aa;
true || aa;
@@
////////////////////////////////////////////////////////////////
2 * 6 + 2 * 4 * 2 - 3 * 4;
2 * 8;
9 + 7;
2 + 7 * 2;
2 * 5 + 6;
2 * 4 * 2;
5 + 4 + 7;
- -16;
((16));
(5 - 1) * 4;
-2 + 18;
-2 * -8;
3 * 2 ** (5 - 2) - 8;
10 + 3 * 2 ** (5 - 2) - 18;
2 * 5 + 3 * (3 - 1) ** (5 - 2) - 6 * 3;
(3 + 1) * (5 - 1);
4 * (5 - 1);
64 / 2 / 2;
19 - 2 - 1;
1 + 2 * 3 + 4 * 2 + 1;
3 * 4 + 5 - 1;
1 + 2 * 3 + 2 + 1 + 2 * 2 + 1 + 1;
2 * 2 ** 3 ** 2 * 2 / 2 ** 7;
- -16;
-2 + 18;
-2 ** 4 + 32;
24 + -2 ** 3;
7 + - - 9;
-(-4 * 2 ** 2);
-(-5 * 2 ** 2 + 2 * 2 ** 2 ** 0);
@@
//console.log(1 + 2 * 3);

//console.log("A value in meters is: ", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J");

//setTimeout(function () { process.exit();}, 1000);

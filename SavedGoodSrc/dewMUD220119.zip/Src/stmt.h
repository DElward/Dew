#ifndef STMTH_INCLUDED
#define STMTH_INCLUDED
/***************************************************************/
/* stmt.h                                                      */
/***************************************************************/

int jrun_exec_block(struct jrunexec * jx, struct jtoken ** pjtok);

/***************************************************************/
#endif /* STMTH_INCLUDED */

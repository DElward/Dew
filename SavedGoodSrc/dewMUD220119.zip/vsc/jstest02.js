// JavaScript source code
// jstest02.js

'use strict';

////////////////////////////////////////////////////////////////////////
function fm101_19a(mm) {
    let tt = 0;
    try {
        tt = tt + 1;
        //console.log("Test 101_19 try");
        if (mm & 1) throw "try throw";
        //console.log("Test 101_19 try - ERROR");
        tt = tt + 9;
    } catch (err101_19a) {
        tt = tt + 100;
        //console.log("Test 101_19 catch");
        if (mm & 2) throw "catch throw";
        tt = tt + 900;
    } finally {
        tt = tt + 10000;
        //console.log("Test 101_19 finally");
        if (mm & 4) throw "finally throw";
        tt = tt + 90000;
    }
    tt = tt + 12345;

    return (tt);
}
function fm101_19b(nn) {
    let mm = 0, tt = 0;
    while (mm < nn) {
        //console.log("mm=", mm);
        try {
            tt = tt + fm101_19a(mm);
        } catch (e101_19) {
            tt = tt + 1000000;
        } finally {
            tt = tt + 9000000;
        }

        mm = mm + 1;
    }
    return (tt);
}
let nn101_19 = fm101_19b(8);
console.log("nn101_19=", nn101_19);   // Expecting 77338056
//if (nn101_19 == 77338056) ngood = ngood + 1; else { console.log("Test 101_19 failed"); nerrs = nerrs + 1; }
console.log("Test 101_19 done");
console.log("--end main tests--");
////////////////////////////////////////////////////////////////////////
